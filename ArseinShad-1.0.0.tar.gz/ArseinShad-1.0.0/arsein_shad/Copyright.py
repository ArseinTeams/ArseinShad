class copyright:
    __Version__ = "1.0.0"
    CopyRight = print(
        f"\n\nArsein Shad library version {__Version__} and Api6 \n\n"
        + "Arsein Copyright (C) 2022 arianabasi Team ArianBOT\n\n\n\n"
        + "در حال فعال شدن کمی صبور باشید..."
    )
    print("........")
    print(" ")
